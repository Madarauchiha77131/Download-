# GX Downloader — Telegram Bot

Telegram version of the Universal Video Downloader web app. Uses the same backend
(`/api/add`, `/api/status`, `/api/proxy_download`) and sends files straight into the chat.

## Deploy on Render
1. Upload these files to a GitHub repo.
2. Render → **New → Web Service** → pick the repo.
   - Build: `pip install -r requirements.txt`
   - Start: `python bot.py`
3. Add one environment variable: `BOT_TOKEN`. Everything else (owner, channel, backend) is in `config.py`.
4. **Make the bot an admin of the channel** — Telegram only lets admins check membership.
5. UptimeRobot → HTTP(s) monitor → `https://<your-service>.onrender.com/health` every 5 minutes.

`/health` returns JSON (`200` ok, `503` if polling stalls). `/health?deep=1` also checks Telegram, DB and backend.

## Premium emoji and coloured buttons
- Needs Bot API 9.4+. Premium emoji in text and on buttons work when the **bot owner has Telegram Premium**.
- Admin → **Emoji Test** shows every emoji and a coloured-button sample. If something is rejected, the bot
  automatically retries with normal emoji; Admin → Settings can switch premium emoji off.
- All ids live in `emoji.py` — edit one line to change an emoji.

## Admin panel (`/admin`)
Statistics · Broadcast (any media, audience All / Active 7d, live progress, stop) · Users (CSV export, top users,
banned list) · Find user (ban / unban / message) · Ban / Unban · Force-join (toggle, change channel, test) ·
Maintenance mode + custom message · Limits (daily quota, cooldown) · Per-platform on/off · Welcome text editor
(keeps formatting and premium emoji) · Logs (recent / failures / clear) · Backup / Restore · Health ·
Emoji test · Admin management (owner only) · Settings (premium emoji, daily auto-backup, new-user alerts).

## Data persistence
Render's free disk is wiped on every deploy. The bot sends a **daily backup** of its database to the owner;
restore it from Admin → Restore. Or attach a Render disk and set `DATABASE_PATH=/var/data/bot.db`.

## Files
`bot.py` entry + user flow · `download.py` backend client & file transfer · `admin.py` admin panel ·
`tg.py` Bot API client · `db.py` SQLite · `ui.py` texts & keyboards · `emoji.py` emoji ids · `config.py` settings
